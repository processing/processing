package com.lowagie.text.pdf.crypto;

/**
 * all parameter classes implement this.
 */
public interface CipherParameters
{
}
