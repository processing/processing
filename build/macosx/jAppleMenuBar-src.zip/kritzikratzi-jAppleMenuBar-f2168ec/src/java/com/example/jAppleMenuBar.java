//
//  jAppleMenuBar.java
//  jAppleMenuBar
//
//  Created by hansi on 25.11.09.
//  Copyright (c) 2009 __MyCompanyName__. All rights reserved.
//
//	For information on setting Java configuration information, including 
//	setting Java properties, refer to the documentation at
//		http://developer.apple.com/techpubs/java/java.html
//

package com.example;

import javax.swing.SwingUtilities;

/**
 * Starting point for the application. General initialization should be done inside
 * the ApplicationController's init() method. If certain kinds of non-Swing initialization
 * takes too long, it should happen in a new Thread and off the Swing event dispatch thread (EDT).
 * 
 * @author hansi
 */
public class jAppleMenuBar {
	public static void main(final String[] args) {
		System.out.println( "OKAY!" ); 
	}
}
